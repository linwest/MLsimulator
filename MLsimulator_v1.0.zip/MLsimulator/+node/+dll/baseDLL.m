classdef baseDLL < handle
    %BASEDLL ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        Node
        APP
        MAC
        Queue
        blocked
    end
    
    methods
        function obj = baseDLL(parameter)
            obj.blocked=false;
            obj.Node=parameter.Node;
            obj.Queue=node.dll.queue(parameter.para_queue);
        end
        
        % receive packet from upper layer
        function recv(obj,pkt_)
            if ~pkt_.isSendUp
                obj.Queue.enQueue(pkt_);
                if ~obj.blocked
                    obj.blocked=true;
                    obj.MAC.recv(obj.Queue.deQueue());
                end
            end
        end
        
        function checkQueue(obj)
            if numel(obj.Queue.pktList)>0
                obj.MAC.recv(obj.Queue.deQueue());
            else
                obj.blocked=false;
            end
        end
    end
    
end

