classdef queue < handle
    %QUEUE ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        maxLen  % max length of the queue
        type    % 'DropTail' or 'DropHead'
    end
    
    properties (SetAccess = private)
        pktList  % storing packets
    end
    
    methods
        function obj = queue(parameter)        
            obj.pktList=struct('packet',{});
            obj.maxLen=parameter.maxLen;
            obj.type=parameter.type;
        end
        
        function enQueue(obj,pkt_)
            %fprintf('%d > %d\n',numel(obj.pktList),obj.maxLen);
            if numel(obj.pktList) >= obj.maxLen
                if isequal(obj.type,'DropHead')
                    obj.pktList=obj.pktList(2:end);
                    obj.pktList(end+1).packet=pkt_;    
                end
            else
               obj.pktList(end+1).packet=pkt_;  
            end
        end
                
        function pkt_=deQueue(obj)
            if numel(obj.pktList)>0
                pkt_ = obj.pktList(1).packet;
                obj.pktList=obj.pktList(2:end);
            end
        end
    end
    
end

