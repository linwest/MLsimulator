classdef cbr < node.app.baseAPP
    %CBR ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        pktSize  % packet size (Byte)
        interval % generating interval (s)
        pktType  % 'FRAME' or 'SEQUENCE'
        Timer
    end
    
    methods
        function obj = cbr(parameter)
            obj=obj@node.app.baseAPP(parameter); % Must explicitly call constructor of SuperClass first;
            obj.Timer=driver.callBackTimer(obj,[]);
            obj.interval=parameter.interval;
            obj.pktSize=parameter.pktSize;
            obj.pktType=parameter.pktType;
            if parameter.randStartTime
                obj.Timer.sched(rand()*obj.interval);  
            else
                obj.Timer.sched(0);
            end
        end
        
        function timerExpire(obj)
            pkt_=packet();
            pkt_.type='cbr';
            pkt_.size=obj.pktSize;
            pkt_.sourceAddr=obj.Node.id;
            if strcmp(obj.pktType,'SEQUENCE')
                pkt_.data=node.app.seqGenerator.newSeq(obj.pktSize*8);
            end            
            obj.DLL.recv(pkt_);
            
            obj.Timer.sched(obj.interval);
        end
    end
    
end

