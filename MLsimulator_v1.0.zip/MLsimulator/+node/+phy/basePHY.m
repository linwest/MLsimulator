classdef basePHY < handle
    %BASEPHY ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        Node
        MAC
        Channel
        power       % sending power (w)
        X           % node position (meter)
        Y           % node position (meter)
        Z           % node position (meter)
        PktTimer    % used to delay propagation
        pktStack    % store packet until propagation end
        pktTime     % packet will be received at which time
    end
    
    methods
        function obj = basePHY(parameter)
            obj.X=parameter.Y;
            obj.Y=parameter.X;
            obj.Z=parameter.Z;
            obj.PktTimer=driver.callBackTimer(obj,'PktTimer');  
            obj.pktStack=[];
            obj.pktTime=[];
            obj.power=parameter.power;    
            obj.Node=parameter.Node;
            obj.Channel=parameter.Channel;
            obj.Channel.addPHY(obj);  % connect node with channel;
        end
                
        function recv(obj,pkt_)
            if pkt_.isSendUp % packet from Channel
                pkt_.layer='PHY';
                    
                index=find(obj.pktTime < pkt_.recvTime,1,'last');
                if isempty(index)
                    obj.pktStack=[pkt_ obj.pktStack];
                    obj.pktTime=[pkt_.recvTime obj.pktTime];
                    obj.PktTimer.resched(pkt_.recvTime-scheduler.getNow());
                else                    
                    obj.pktStack=[obj.pktStack(1:index) pkt_ obj.pktStack(index+1:end)];
                    obj.pktTime=[obj.pktTime(1:index) pkt_.recvTime obj.pktTime(index+1:end)];
                end                
                
            else % packet from MAC          
                obj.Node.trace(pkt_);    
                pkt_.layer='PHY';
                pkt_.power=obj.power;
                obj.msgFromUp(pkt_);       
            end
        end        
        
        function pkt_=msgFromUp(obj,pkt_)
            obj.Channel.recv(pkt_,obj.Node);
        end
        
        function pkt_=msgFromDown(obj,pkt_)
        	obj.MAC.recv(pkt_);
        end
        
        function isDealed = timerExpire(obj,timerId)
            if strcmp(timerId,'PktTimer')                
                
                obj.msgFromDown(obj.pktStack(1));  
                if numel(obj.pktTime) > 1
                    obj.PktTimer.sched(obj.pktTime(2)-obj.pktTime(1));
                end
                obj.pktStack=obj.pktStack(2:end);
                obj.pktTime=obj.pktTime(2:end);
                isDealed = true;
            else
                isDealed = false;
            end
        end
    end
    
end

