classdef encoder
    %ENCODER ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
    end
    
    methods (Static)        
        function [data, output]  = code(data,parameter)    
            output=[];
            switch parameter.type
                case 'CC' % convolutional code                    
%                     *IMPROTANT*
%                     last column of code_book times the data before stored in memory
%                     last second column times first memory
% 
%                    length of memory = size(code_book_,2) - 1
%                    code_book means generation formula
%                     v_0=D^2+1                        | 0 1 0 1 |
%                     v_1=D^3+D     =====> code_book = | 1 0 1 0 |
%                     v_2=D+1                          | 0 0 1 1 |
%                     no feedback if it is []
%                     or like:   | 0 1 0 |
%                     feedback = | 0 0 1 |
%                                | 0 0 0 | % last row always '0 0 ... 0'
                    code_book=parameter.code_book;
                    feedback=parameter.feedback;
                    m = size(code_book,2) - 1;
                    %seq=[seq zeros(1,m)];
                    if isempty(feedback)
                        %no feedback case
                        data=[zeros(1,m) data];
                        mem=data; 
                        for i=1:m
                            data=circshift(data,[0,-1]);
                            mem=[mem;data];
                        end
                        data=mod(code_book*mem,2);
                        data=reshape(data,1,numel(data));
                    else
                        %feedback case
                        mem=zeros(m+1,1); % m-th memory and 1 input of sequence
                        seq_out=[];
                        for i=1:length(data)
                            mem=mod(feedback*mem,2);
                            mem(end)=data(i);
                            seq_out=[seq_out ; mod(code_book*mem,2)];
                        end

                        s_num=2^m;
                        for i=1:s_num
                            for j=1:m
                                s(i,j)=mod(floor((i-1)/2^(m-j)),2);
                            end
                        end
                        for i=1:s_num  
                            data=s(i,:);
                            mem_tmp=mem;
                            seq_out_tmp=[];
                            for j=1:length(data)
                                mem_tmp(end)=data(j);
                                mem_tmp=mod(feedback*mem_tmp,2);
                                seq_out_tmp=[seq_out_tmp ; mod(code_book*mem_tmp,2)];
                            end
                            mem_tmp(end)=[];
                            if isequal(mem_tmp,zeros(m,1))
                                break;
                            end
                        end
                        seq_out=[seq_out ; seq_out_tmp];

                        data=seq_out';
                    end
                case 'TURBO' % turbo code    
                    codePara1.type=parameter.type1;
                    codePara1.code_book=parameter.code_book1;
                    codePara1.feedback=parameter.feedback1;
                    
                    codePara2.type=parameter.type2;
                    codePara2.code_book=parameter.code_book2;
                    codePara2.feedback=parameter.feedback2;
                    
                    code1=node.phy.encoder.code(data,codePara2);
                    [data2,pattern]=node.phy.interleaver.interleave(data,parameter.interleave_mode);
                    code2=node.phy.encoder.code(data2,codePara1);
                    
                    data_len=numel(data);
                    code1(data_len+1:end)=[];
                    code2(data_len+1:end)=[];
                    
                    switch parameter.rate
                        case '1/3'
                            data=reshape([data; code1; code2],1,data_len*3);
                        case '1/2'
                            code1(2:2:data_len)=code2(2:2:data_len);
                            data=reshape([data; code1],1,data_len*2);
                    end
                    output=pattern;
            end
        end
    end
    
end

