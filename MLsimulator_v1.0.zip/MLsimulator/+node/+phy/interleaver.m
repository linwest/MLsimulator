classdef interleaver
    %INTERLEAVER ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    methods (Static)        
        function [data,pattern] = interleave(data, mode, pattern)
            switch mode
                case 'RANDOM'
                    if nargin < 3
                        [temp, pattern] = sort(rand(size(data)));
                    end
                    data=data(pattern);
            end
        end
        
        function data = deinterleave(data, mode, pattern)
            switch mode
                case 'RANDOM'
                    data(pattern)=data;
            end
        end
    end
    
end

