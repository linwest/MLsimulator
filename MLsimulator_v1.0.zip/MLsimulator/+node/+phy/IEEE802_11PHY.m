classdef IEEE802_11PHY < node.phy.basePHY
    %IEEE802_11PHY ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties (SetAccess = protected)
        PowerMonitor
        CaptTimer     % timer for 'CAPTURING' state
        RecvTimer     % timer for 'RECEIVING' state
        TranTimer     % timer for 'TRNSMITTING' state
        state         % 'SENSING' 'TRNSMITTING' 'CAPTURING' 'RECEIVING'
        pktRecv       % packet wait to be received
        recvEndTime   % receive packet end at which time
        codeParameter % used for encoder/decoder
        recaptureSwitch % whether recapture new packet with higer SINR
        minSINR       % min SINR when receiving a packet
    end
    
    methods
        function obj = IEEE802_11PHY(parameter)
            obj=obj@node.phy.basePHY(parameter); % Must explicitly call constructor of SuperClass first;
            
            pM_parameter=defaultConfig('powerMonitor');
            obj.PowerMonitor=node.phy.powerMonitor(obj,pM_parameter);
            obj.CaptTimer=driver.callBackTimer(obj,'CaptTimer');
            obj.RecvTimer=driver.callBackTimer(obj,'RecvTimer');
            obj.TranTimer=driver.callBackTimer(obj,'TranTimer');        
            obj.recaptureSwitch=parameter.recaptureSwitch;
            obj.codeParameter= parameter.codeParameter;
            obj.recvEndTime=0;    
            obj.state='SENSING';
            
        end
        
        function pkt_=msgFromUp(obj,pkt_)            
            if ~isempty(pkt_.data)
                pkt_.originalData=pkt_.data;
                [pkt_.data, pkt_.header.codeInfo]= node.phy.encoder.code(pkt_.data,obj.codeParameter);
                pkt_.data= node.phy.modulator.modulate(pkt_.data,pkt_.moduMode);
                pkt_.header.txTime=pkt_.header.txTime*numel(pkt_.data)/numel(pkt_.originalData);
            end
            switch obj.state
                case 'SENSING'
                    % nothing to do
                case 'TRNSMITTING'
                    warning('PHY[%d] cannot transmit more than one packet simultaneously, MAC recvState=%s, tranState=%s.',...
                          obj.Node.id,obj.MAC.recvState,obj.MAC.tranState);
                case 'CAPTURING'
                    obj.pktRecv=[];
                    obj.recvEndTime=0;
                    obj.CaptTimer.cancel();                    
                case 'RECEIVING'
                    obj.pktRecv=[];
                    obj.RecvTimer.cancel();        
                otherwise
                    error('No such state ''%s'' in IEEE802_11PHY.',obj.state);
            end
            if ~strcmp(obj.state,'TRNSMITTING')
                obj.TranTimer.sched(pkt_.header.head_duration+pkt_.header.txTime);
                %fprintf('Node[%d] tran start at %.9f.\n',obj.Node.id,obj.Node.Scheduler.getNow());
                obj.state='TRNSMITTING';
                obj.PowerMonitor.recordPower(pkt_.power,pkt_.header.head_duration+pkt_.header.txTime);

                obj.Channel.recv(pkt_,obj.Node);
            else
                obj.MAC.tranEnd();
            end
        end
        
        function pkt_=msgFromDown(obj,pkt_)   % receive a packet
            if pkt_.power < obj.PowerMonitor.thresh
                return;
            end
            obj.PowerMonitor.recordPower(pkt_.power,pkt_.header.head_duration+pkt_.header.txTime);
            obj.PowerMonitor.csBusyCheck();
            %fprintf('Node[%d] recv packet at %.9f in PHY state=%s\n',obj.Node.id,obj.Node.Scheduler.getNow(),obj.state);
            switch obj.state
                case 'SENSING'
                    % The packet power continues until received
                    % So SINR should minus packet power itself
                    sinr_=abs(pkt_.power/(obj.PowerMonitor.getPowerLevel()-pkt_.power)); % SINR ratio for header, no negetive value
                    
                    %fprintf('Node[%d] SINR=%g, power=%g, noise=%g\n',obj.Node.id,sinr_,pkt_.power,obj.PowerMonitor.getPowerLevel());
                    if sinr_ > constants.IEEE802_11ModuTable(1).SINR   % use BPSK to capture header                        
                        obj.pktRecv=pkt_;
                        %fprintf('Node[%d] capture pkt\n',obj.Node.id);
                        obj.state='CAPTURING';
                        obj.MAC.channelBusy();
                        obj.recvEndTime=scheduler.getNow()+pkt_.header.head_duration;
                        obj.MAC.channelBusy();
                        obj.CaptTimer.sched(pkt_.header.head_duration);
                    end
                case 'TRNSMITTING'
                    % do not receive pkt because PHY is sending packet now
                case 'CAPTURING'
                    sinr_=abs(obj.pktRecv.power/(obj.PowerMonitor.getPowerLevel()-obj.pktRecv.power));
                    if sinr_ < constants.IEEE802_11ModuTable(1).SINR % capture failed
                        obj.recvEndTime=0;
                        obj.CaptTimer.cancel();
                        sinr_=abs(pkt_.power/(obj.PowerMonitor.getPowerLevel()-pkt_.power));
                        if sinr_ > constants.IEEE802_11ModuTable(1).SINR
                            % capture new packet with higher SINR
                            obj.pktRecv=pkt_;
                            obj.recvEndTime=scheduler.getNow()+pkt_.header.head_duration;
                            obj.MAC.channelBusy();
                            obj.CaptTimer.sched(pkt_.header.head_duration);
                        else
                            % no packet can be captured
                            obj.pktRecv=[];
                            obj.state='SENSING';                            
                        end
                    end
                case 'RECEIVING'
                    sinr_=abs(obj.pktRecv.power/(obj.PowerMonitor.getPowerLevel()-obj.pktRecv.power));
                    if isempty(pkt_.moduMode)
                        index=1; % use basic module mode for default
                    else
                        if isfield(constants.IEEE802_11ModuTable,pkt_.moduMode)
                            index=eval(['constants.IEEE802_11ModuTable.' pkt_.moduMode]);
                        else
                            error('No parameter for such modulate mode ''%s''.',pkt_.moduMode);
                        end
                    end
                    if isempty(obj.pktRecv.data) && ... % packet is 'frame' but not 'sequence'
                            sinr_ < constants.IEEE802_11ModuTable(index).SINR % receive failed
                    
                        obj.RecvTimer.cancel();
                        sinr_=abs(pkt_.power/(obj.PowerMonitor.getPowerLevel()-pkt_.power));
                        if obj.recaptureSwitch && sinr_ > constants.IEEE802_11ModuTable(1).SINR
                            % capture new packet with higher SINR
                            obj.pktRecv=pkt_;                            
                            obj.recvEndTime=scheduler.getNow()+pkt_.header.head_duration;
                            obj.MAC.channelBusy();
                            obj.CaptTimer.sched(pkt_.header.head_duration);
                            obj.state='CAPTURING';                     
                        else % cannot receive remaining part of packet
                            obj.pktRecv.isError=true;
                            obj.state='SENSING';   
                        end
                    elseif obj.minSINR > sinr_
                        obj.minSINR=sinr_;
                    end                    
                otherwise
                    error('No such state ''%s'' in IEEE802_11PHY.',obj.state);
            end
            
        end
        
        function timerExpire(obj,timerId)
            if obj.timerExpire@node.phy.basePHY(timerId)
                return;
            end
            switch timerId
                case 'CaptTimer'
                    % capture packet succeed
                    % SINR for payload
                    sinr_=abs(obj.pktRecv.power/(obj.PowerMonitor.getPowerLevel()-obj.pktRecv.power));                    
                    if isempty(obj.pktRecv.moduMode)
                        index=1; % use basic module mode for default
                    else
                        if isfield(constants.IEEE802_11ModuTable,obj.pktRecv.moduMode)
                            index=eval(['constants.IEEE802_11ModuTable.' obj.pktRecv.moduMode]);
                        else
                            error('No parameter for such modulate mode ''%s''.',obj.pktRecv.moduMode);
                        end
                    end
                    if isempty(obj.pktRecv.data) && ... % packet is 'frame' but not 'sequence'
                            sinr_ < constants.IEEE802_11ModuTable(index).SINR % receive failed
                        obj.pktRecv=[];
                        obj.state='SENSING';                           
                    else
                        if obj.PowerMonitor.getPowerLevel() == obj.pktRecv.power
                            obj.minSINR=obj.pktRecv.power/obj.Channel.noisePower;
                        else                            
                            obj.minSINR=sinr_;
                        end
                        obj.RecvTimer.sched(obj.pktRecv.header.txTime);
                        obj.state='RECEIVING';   
                    end
                case 'RecvTimer'        
                    % receive packet succeed
                    obj.state='SENSING';  
                    %fprintf('Node[%d] recv pkt in PHY\n',obj.Node.id);
                    if ~isempty(obj.pktRecv.data)                        
                        interference_ = obj.pktRecv.power/obj.minSINR - obj.Channel.noisePower;
                        if interference_ > 0 
                            % fading of channel noise has been calculated in channel
                            % only add interference to data here
                            sinr_=abs(obj.pktRecv.power/interference_); 
                            obj.pktRecv.data= obj.pktRecv.data + sqrt(0.5 / sinr_) *...
                                        (randn(size(obj.pktRecv.data))+1i*randn(size(obj.pktRecv.data)));
                        end
                        sinr_=obj.minSINR;
                        obj.pktRecv.data = node.phy.modulator.demodulate(obj.pktRecv.data,obj.pktRecv.moduMode,sinr_);
                        codeParameter_=obj.codeParameter;
                        codeParameter_.code_position='innerCode';
                        codeParameter_.La=[];
                        codeParameter_.Lc=4*sinr_;
                        if isfield(obj.pktRecv.header,'codeInfo')
                            codeParameter_.codeInfo=obj.pktRecv.header.codeInfo;
                        end
                        obj.pktRecv.data = node.phy.decoder.code(obj.pktRecv.data,codeParameter_);
                        obj.pktRecv.BER = sum(obj.pktRecv.originalData ~= obj.pktRecv.data) / numel(obj.pktRecv.originalData);
                        obj.pktRecv.isError = obj.pktRecv.BER > rand();
                        fprintf('Node[%d] BER is %g\n',obj.Node.id,obj.pktRecv.BER);
                    end
                    obj.MAC.recv(obj.pktRecv);
                case 'TranTimer'      
                    % transmit packet succeed
                    obj.state='SENSING';    
                    %fprintf('Node[%d] tran end at %.9f.\n',obj.Node.id,obj.Node.Scheduler.getNow());
                    obj.MAC.tranEnd();
                otherwise
                    error('No such timer ''%s'' in IEEE802_11PHY.',timerId);                  
            end
        end
    end
    
end

