classdef decoder
    %DECODER ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
    end
    
    methods (Static)        
        function [data, output] = code(data,parameter)
            switch parameter.type
                case 'CC' % convolutional code   
                    % BCJR
                    code_book=parameter.code_book;
                    feedback=parameter.feedback;
                    code_position=parameter.code_position;
                    La=parameter.La;
                    Lc=parameter.Lc;
                    m = size(code_book,2) - 1;
                    n=size(code_book,1); % Convolutional Code (n,1,m)
                    K=length(data)/n;
                    h=K-m;     
                    if isempty(feedback)
                        feedback=[zeros(m,1) eye(m);zeros(1,m+1)];
                    end
                    data=reshape(data,n,K);

                    if isempty(La)
                        La=zeros(1,h);
                    end

                    s_num=2^m;
                    % "s_index" is state transition matrix
                    % 1st row is changed index when input 0
                    % 2nd row is changed index when input 1,
                    for i=1:s_num
                        for j=1:m
                            s(j,i)=mod(floor((i-1)/2^(m-j)),2);
                        end
                    end
                    
                    %state change to what
                    s0=mod(feedback*[s;zeros(1,s_num)],2); %next input is 0
                    s0(end,:)=[];
                    s1=mod(feedback*[s;ones(1,s_num)],2);  %next input is 1
                    s1(end,:)=[];

                    weight=power(2,m-1:-1:0);
                    %index of original state is [0 1 2 3 ... s_num-1]
                    s_index=[weight*s0;         %changed index when input 0
                            weight*s1]+1;        %changed index when input 1

                    for i=1:s_num
                        for j=1:m
                            s(j,i)=mod(floor((i-1)/2^(m-j)),2); % state in each memory bit
                        end
                    end
                    % "v0" and "v1" are next output codewords for each state
                    % |           |   | s1_bit1 s2_bit1 |
                    % | code_book | * | s1_bit2 s2_bit2 |
                    % |           |   | input_0 input_0 |
                    v0=mod(code_book*[s;zeros(1,s_num)],2)*2-1; % next input is 0
                    v1=mod(code_book*[s;ones(1,s_num)],2)*2-1;  % next input is 1


                    a=-Inf*ones(K+1,s_num); %��(l,s)
                    b=a;                %��(l,s)
                    a(1,1)=0;
                    b(K+1,1)=0;

                    y=zeros(K,s_num,2);
                    for i=1:h
                        for j=1:s_num
                            y(i,j,1)=-La(i)/2+Lc/2*data(:,i)'*v0(:,j);%��(l,s',s), input is 0
                            y(i,j,2)=La(i)/2+Lc/2*data(:,i)'*v1(:,j);%��(l,s',s), input is 1
                        end
                    end
                    for i=h+1:K
                        for j=1:s_num
                            y(i,j,1)=Lc/2*data(:,i)'*v0(:,j);%��(l,s',s), input is 0
                            y(i,j,2)=Lc/2*data(:,i)'*v1(:,j);%��(l,s',s), input is 1
                        end
                    end

                    for i=1:K
                        for j=1:s_num         
                            a(i+1,s_index(1,j))=functions.max_star(y(i,j,1)+a(i,j),a(i+1,s_index(1,j))); %input is 0
                            a(i+1,s_index(2,j))=functions.max_star(y(i,j,2)+a(i,j),a(i+1,s_index(2,j))); %input is 1

                            b(K-i+1,j)=functions.max_star(y(K-i+1,j,1)+b(K-i+2,s_index(1,j)), ...  %input is 0
                                                y(K-i+1,j,2)+b(K-i+2,s_index(2,j)));     %input is 1
                        end
                    end

        %             %initial and final state is '0 0 ... 0', to pick up not possible state
        %           %%%%method 1%%%
                    b(a==-Inf)=-Inf;
                    a(b==-Inf)=-Inf;
        %           %%%%method 2%%%
        %             a(end,2:end)=-Inf;
        %             for i=K:-1:K-m+1
        %                 for j=1:s_num   
        %                     if a(i+1,s_index(1,j))==-Inf && a(i+1,s_index(2,j))==-Inf
        %                         a(i,j)=-Inf;
        %                     end
        %                  end
        %             end

                    LLR_limit=300;
                    % calculate LLR of systematic bits
                    La0=-Inf*ones(1,h);
                    La1=La0;
                    for i=1:h
                        for j=1:s_num
                            La0(i)=functions.max_star(b(i+1,s_index(1,j))+y(i,j,1)+a(i,j),La0(i));  %input is 0
                            La1(i)=functions.max_star(b(i+1,s_index(2,j))+y(i,j,2)+a(i,j),La1(i));  %input is 1
                        end
                    end            
                    data=La1-La0;
                    data(data>LLR_limit)=LLR_limit;
                    data(data<-LLR_limit)=-LLR_limit;

                    if(code_position=='outerCode')
                        % calculate LLR of coded bits
                        La_code0=-Inf*ones(n,K);
                        La_code1=La_code0;
                        for i=1:K % input bit index of now
                            for j=1:s_num % state of now
                                % calculate memory bit
                                for s_i=1:m
                                    s_tmp(s_i)=mod(floor((j-1)/2^(m-s_i)),2); % state in each memory bit
                                end
                                for c_i=1:n % each row of code_book, calculate output codeword bit by bit
                                    for next_input=0:1 % next input is 0 or 1
                                        s_tmp(m+1)=next_input;
                                        codeword=mod(code_book(c_i,:)*s_tmp',2);
                                        if codeword==0   % if codeword is 0, calculate the LLR of 0
                                            La_code0(c_i,i)=functions.max_star(b(i+1,s_index(next_input+1,j))+y(i,j,next_input+1)+a(i,j),La_code0(c_i,i));
                                        else             % if codeword is 1, calculate the LLR of 1
                                            La_code1(c_i,i)=functions.max_star(b(i+1,s_index(next_input+1,j))+y(i,j,next_input+1)+a(i,j),La_code1(c_i,i));                                    
                                        end
                                    end
                                end
                            end
                        end
                        La_code=La_code1-La_code0;
                        La_code=reshape(La_code,1,n*K);
                        La_code(La_code>LLR_limit)=LLR_limit;
                        La_code(La_code<-LLR_limit)=-LLR_limit;   

                        output.LLR_code=La_code;
                    end
                    output.LLR=data;
                case 'TURBO' % turbo code   
                    pattern=parameter.codeInfo;
                    
                    codePara1.Lc=parameter.Lc;
                    codePara1.type=parameter.type1;
                    codePara1.code_book=[zeros(1,size(parameter.code_book1,2)-1) 1; parameter.code_book1];
                    codePara1.feedback=parameter.feedback1;
                    codePara1.code_position='innerCode';
                    m1 = size(codePara1.code_book,2) - 1;
                    
                    codePara2.Lc=parameter.Lc;
                    codePara2.type=parameter.type2;
                    codePara2.code_book=[zeros(1,size(parameter.code_book2,2)-1) 1; parameter.code_book2];
                    codePara2.feedback=parameter.feedback2;
                    codePara2.code_position='innerCode';
                    m2 = size(codePara2.code_book,2) - 1;
                                        
                    switch parameter.rate
                        case '1/3'
                            code1=data(2:3:end);
                            code2=data(3:3:end);
                            data=data(1:3:end);
                        case '1/2'
                            code1=zeros(1,numel(data)/2);
                            code2=code1;
                            code1(1:2:end)=data(2:4:end);
                            code1(2:2:end)=data(4:4:end);
                            data=data(1:2:end);
                    end
                    data_len=numel(data);
                    code1=reshape([data zeros(m1);code1 zeros(m1)],1,(data_len+m1)*2);
                    code2=reshape([data(pattern) zeros(m2);code2  zeros(m2)],1,(data_len+m2)*2);
                    codePara1.La=zeros(1,data_len);
                    
                    for i=1:parameter.iter_time
                        [~, output_tmp]=node.phy.decoder.code(code1,codePara1);                    
                        extrinsic_info=output_tmp.LLR-codePara1.La;
                        codePara2.La=extrinsic_info(pattern);

                        [data, output_tmp]=node.phy.decoder.code(code2,codePara2);
                        extrinsic_info=output_tmp.LLR-codePara2.La;
                        codePara1.La(pattern)=extrinsic_info;    
                    end
                    
                    data(pattern)=data;
            end
            data= data>0;
        end
    end
    
end

