classdef powerMonitor < handle
    %POWERMONITOR ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q    
    
    properties
        PHY
    end
    
    properties (SetAccess = private)
        powerList  % storing power of packets
        powerTime  % power duration time
        powerLevel % total power at now
        thresh     % only record power higher than treshold
        CSThresh   % channel sensing threshold
        Timer
    end
    
    methods
        function obj = powerMonitor(phy_,parameter)
            obj.PHY=phy_;
            obj.powerList=[];
            obj.powerLevel=0;
            obj.thresh=parameter.thresh;
            obj.CSThresh=parameter.CSThresh;
            obj.Timer=driver.callBackTimer(obj,[]);  
        end            
        
        function recordPower(obj,pwr_,duration_)
            if pwr_ > obj.thresh
                obj.powerLevel=obj.powerLevel+pwr_;
                now_=scheduler.getNow();
                time_=now_+duration_;
                if isempty(obj.powerTime)
                    obj.powerList=pwr_;
                    obj.powerTime=time_;       
                    obj.Timer.sched(duration_,4);  
                else
                    index=find(obj.powerTime>time_,1);
                    if isempty(index)
                        obj.powerList=[obj.powerList pwr_];
                        obj.powerTime=[obj.powerTime time_];                
                    else                    
                        obj.powerList=[obj.powerList(1:index-1) pwr_ obj.powerList(index:end)];
                        obj.powerTime=[obj.powerTime(1:index-1) time_ obj.powerTime(index:end)];
                        if index==1
                            obj.Timer.resched(duration_,4);
                        end
                    end  
                end
            end
        end        
        function csBusyCheck(obj)
            if obj.powerLevel > obj.CSThresh
                obj.PHY.MAC.channelBusy();
            end
        end
        function pwr_ = getPowerLevel(obj)
            pwr_=obj.PHY.Channel.noisePower;
            if pwr_ < obj.powerLevel
                pwr_=obj.powerLevel;
            end
        end
        
        function timerExpire(obj)
            obj.powerLevel=obj.powerLevel-obj.powerList(1);
            if numel(obj.powerTime) > 1
                obj.Timer.sched(obj.powerTime(2)-obj.powerTime(1),4);
            end
            obj.powerList=obj.powerList(2:end);
            obj.powerTime=obj.powerTime(2:end);
            
            if obj.powerLevel < obj.CSThresh && obj.PHY.recvEndTime <= scheduler.getNow()
            	obj.PHY.MAC.channelIdle();
            end
        end
    end
    
end

