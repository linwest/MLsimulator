classdef baseMAC < handle
    %BASEMAC ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        Node
        DLL
        PHY
    end
    
    methods
        function obj = baseMAC(parameter)
            obj.Node=parameter.Node;
        end
                
        function recv(obj,pkt_)   
            if pkt_.isSendUp % packet from PHY                 
                obj.Node.trace(pkt_);
                pkt_.layer='MAC';
                pkt_=obj.msgFromDown(pkt_);  
                if ~isempty(pkt_)
                    obj.Node.trace(pkt_);
                end
            else % packet from DLL
                obj.msgFromUp(pkt_);   
            end
        end
        
        function pkt_=msgFromUp(obj,pkt_)
            pkt_.layer='MAC';
            pkt_.lastHop=obj.Node.id;
        	obj.PHY.recv(pkt_);
            obj.DLL.blocked=false;
        end
        
        function pkt_=msgFromDown(obj,pkt_)
        end
    end
    
end

