classdef IEEE802_11MAC < node.mac.baseMAC
    %IEEE802_11MAC ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties (SetAccess = protected)
        % MAC parameters
        type           % 'STA' or 'AP'
        slotTime       % slot time
        IFS            % current InterFrame Space value
        SIFS           % SIFS time
        DIFS           
        EIFS
        PIFS
        recvNode       % receiving node list
        RTSlen         % length of RTS
        CTSlen         % length of CTS
        ACKlen         % length of ACK
        FCSlen         % length of FCS field
        MACheaderLen   % length of MAC header for DATA
        RTStime        % transmition time of RTS
        CTStime        % transmition time of CTS
        ACKtime        % transmition time of ACK
        headerDuration % headerDuration for PHY preamble
        symbolDuration
        CW             % current contention window
        CWmin          % min contention window
        CWmax          % max contention window
        RTSthreshold
        maxPropagationDelay
        shortRetryLimit    
        longRetryLimit
        shortRetryCounter
        longRetryCounter
        NAVendTime     % the time NAV will expire
        staIndex       % send data to which station, only used in AP
        
        % timers
        TranTimer     % transmit Timer, wait for response after transmit a packet
        IFSTimer      % IFS Timer
        BKTimer       % backoff Timer
        NAVTimer      % NAV Timer
        
        % states, 'WAIT_SIFS' or 'WIFS' can only exist one among all state variables at the same time 
        recvState     % receive state 'IDLE' 'WAIT_SIFS' 'RESPONSING'
        tranState     % transmit state 'IDLE' 'RTS_PENDING' 'DATA_PENDING' 'SENDING_RTS' 'SENDING_DATA' 'WAIT_CTS' 'WAIT_ACK' 'WAIT_SIFS'
        csState       % channel sensing state 'noCSnoNAV' 'noCSNAV' 'CSnoNAV' 'CSNAV' 'WIFS'
        bkState       % backoff state 'IDLE' 'RUNNING' 'PAUSE'
        
        % backoff parameters
        bkStartTime   % start time of backoff
        bkSlots       % remaining backoff slots
        
        % packet caches
        pktRTS        % RTS packet
        pktDATA       % DATA packet
        pktCtrl       % CTS or ACK packet
    end
    
    methods
        function obj = IEEE802_11MAC(parameter)
            obj=obj@node.mac.baseMAC(parameter); % Must explicitly call constructor of SuperClass first;
            obj.type=parameter.type;
            obj.slotTime=parameter.slotTime;
            obj.SIFS=parameter.SIFS;
            obj.RTSlen=parameter.RTSlen;
            obj.CTSlen=parameter.CTSlen;
            obj.ACKlen=parameter.ACKlen;
            obj.FCSlen=parameter.FCSlen;    
            obj.MACheaderLen=parameter.MACheaderLen;
            obj.headerDuration=parameter.headerDuration;
            obj.symbolDuration=parameter.symbolDuration;
            obj.CWmin=parameter.CWmin;
            obj.CWmax=parameter.CWmax;
            obj.RTSthreshold=parameter.RTSthreshold;
            obj.maxPropagationDelay=parameter.maxPropagationDelay;
            obj.shortRetryLimit=parameter.shortRetryLimit;    
            obj.longRetryLimit=parameter.longRetryLimit;
            
            obj.BKTimer=driver.callBackTimer(obj,'BKTimer');
            obj.NAVTimer=driver.callBackTimer(obj,'NAVTimer');
            obj.TranTimer=driver.callBackTimer(obj,'TranTimer');
            obj.IFSTimer=driver.callBackTimer(obj,'IFSTimer');
            
            obj.recvState='IDLE';
            obj.tranState='IDLE';
            obj.csState='noCSnoNAV';
            obj.bkState='IDLE';
            obj.bkStartTime=-1;
            obj.bkSlots=-1;
            obj.NAVendTime=-1;
            obj.CW=obj.CWmin;
            obj.shortRetryCounter=0;
            obj.longRetryCounter=0;
            obj.staIndex=1;
                          
            symbols = ceil(obj.RTSlen*8/constants.IEEE802_11ModuTable(1).NDBPS); % PADDING BITS, FILL SYMBOl                
            obj.RTStime = obj.headerDuration + symbols * obj.symbolDuration;
            symbols = ceil(obj.CTSlen*8/constants.IEEE802_11ModuTable(1).NDBPS);
            obj.CTStime = obj.headerDuration + symbols * obj.symbolDuration;
            symbols = ceil(obj.ACKlen*8/constants.IEEE802_11ModuTable(1).NDBPS);
            obj.ACKtime = obj.headerDuration + symbols * obj.symbolDuration;
            
            obj.DIFS=obj.SIFS + 2 * obj.slotTime;    
            obj.EIFS=obj.SIFS + obj.DIFS + obj.ACKtime;
            obj.PIFS=obj.SIFS + obj.slotTime;
            obj.IFS =obj.EIFS;
        end
        
        function addRecvNode(obj,id_)
            obj.recvNode(end+1)=id_;
        end
        
        function pkt_=msgFromUp(obj,pkt_)
            obj.genFrameDATA(pkt_);
            if (~isempty(obj.pktDATA.nextHop)) && obj.pktDATA.nextHop~=0 ...
                    && obj.pktDATA.size > obj.RTSthreshold
                obj.genFrameRTS();
            end
            
            if strcmp(obj.bkState,'IDLE')
                % no backoff
                if strcmp(obj.csState,'noCSnoNAV') && strcmp(obj.tranState,'IDLE') && strcmp(obj.recvState,'IDLE') 
                    % CS idle
                    if isempty(obj.pktRTS)
                        obj.tranState='SENDING_DATA';
                        obj.transmit(obj.pktDATA);
                    else
                        obj.tranState='SENDING_RTS';
                        %fprintf('Node[%d] send RTS 2 at %.9f recvState=%s\n',obj.Node.id,obj.Node.Scheduler.getNow(),obj.recvState);
                        obj.transmit(obj.pktRTS);
                    end
                else             
                    % CS busy
                    if isempty(obj.pktRTS)
                        obj.tranState='DATA_PENDING';
                    else
                        obj.tranState='RTS_PENDING';
                    end
                end                
            else
                % backoff busy
                if isempty(obj.pktRTS)
                    obj.tranState='DATA_PENDING';
                else
                    obj.tranState='RTS_PENDING';
                end
            end
            
        end
        
        function pkt_=msgFromDown(obj,pkt_)     % set pkt_=[] if do not receive it
            if pkt_.isError
                obj.IFS=obj.EIFS;                
                pkt_=[];
                return;
            end
            obj.IFS=obj.DIFS;
            r_addr=pkt_.nextHop;
            if  isempty(r_addr) || r_addr==obj.Node.id || r_addr==0 
                % send to this node or broadcast
%                 if strcmp(obj.tranState,'DATA_PENDING')
%                     pkt_=[]; % do not receive the packet
%                 elseif strcmp(obj.tranState,'RTS_PENDING')                    
%                     if strcmp(obj.bkState,'RUNNING')
%                         obj.pauseBK();
%                     end
%                 else
%                     pkt_=obj.recvPkt(pkt_);
%                 end              
                if strcmp(obj.bkState,'RUNNING')
                    obj.pauseBK();
                end
                pkt_=obj.recvPkt(pkt_);
            else
                obj.setNAV(pkt_.header.NAV);
                pkt_=[]; % do not receive the packet
            end            
        end
        
        function pkt_=recvPkt(obj,pkt_)             
            %fprintf('Node[%d] recv packet at %.9f\n',obj.Node.id,obj.Node.Scheduler.getNow());
            r_addr=pkt_.nextHop;
            switch pkt_.header.frameType
                case 'RTS'
                    %fprintf('Node[%d] recv RTS at %.9f, cs=%s\n',obj.Node.id,obj.Node.Scheduler.getNow(),obj.csState);
                    if strcmp(obj.csState,'CSNAV') || strcmp(obj.csState,'noCSNAV')
                        obj.recvState='IDLE';
                    else
                        obj.genFrameCTS(pkt_);
                        if strcmp(obj.csState,'WIFS') % this case can happen at a time point
                            obj.csState='noCSnoNAV';
                            obj.IFSTimer.cancel();
                        end
                        obj.IFSTimer.sched(obj.SIFS);
                        %fprintf('Node[%d] set WIFS 4 at%.9f, bkState=%s\n',obj.Node.id,scheduler.getNow(),obj.bkState);
                        obj.recvState='WAIT_SIFS';
                    end
                case 'CTS'
                    %fprintf('Node[%d] recv CTS at %.9f, tranState=%s\n',obj.Node.id,obj.Node.Scheduler.getNow(),obj.tranState);
                    obj.recvState='IDLE';                    
                    if strcmp(obj.tranState,'WAIT_CTS')
                        obj.pktRTS=[];
                        obj.TranTimer.cancel();      
                        obj.shortRetryCounter=0;    
                        if strcmp(obj.csState,'WIFS') % this case can happen at a time point
                            obj.csState='noCSnoNAV';
                            obj.IFSTimer.cancel();
                        end
                        obj.IFSTimer.sched(obj.SIFS);   
                        %fprintf('Node[%d] set WIFS 5 at%.9f, bkState=%s\n',obj.Node.id,scheduler.getNow(),obj.bkState);           
                        obj.tranState='WAIT_SIFS';
                    else
                        error('Error transmit state ''%s'' when receive CTS in Node[%d].',obj.tranState,obj.Node.id);
                    end
                case 'ACK'
                    obj.recvState='IDLE';
                    %fprintf('Node[%d] recv ACK\n',obj.Node.id);
                    if strcmp(obj.tranState,'WAIT_ACK')
                        obj.TranTimer.cancel();
                        obj.shortRetryCounter=0;
                        obj.longRetryCounter=0;
                        obj.pktDATA=[];
                        obj.CW=obj.CWmin;
                        obj.tranState='IDLE';
                        obj.startBK();
                        obj.DLL.checkQueue();
                    else
                        error('Error transmit state ''%s'' when receive ACK.',obj.tranState);
                    end
                case 'DATA'
                    if r_addr==obj.Node.id % packet send to this node                        
                        pkt_=obj.recvDATA(pkt_);
                        obj.genFrameACK(pkt_);
                        if strcmp(obj.csState,'WIFS') % this case can happen at a time point
                            obj.csState='noCSnoNAV';
                            obj.IFSTimer.cancel();
                        end
                        obj.IFSTimer.sched(obj.SIFS);
                        %fprintf('Node[%d] set WIFS 1 at%.9f, bkState=%s\n',obj.Node.id,scheduler.getNow(),obj.bkState);
                        obj.recvState='WAIT_SIFS';
                    elseif isempty(r_addr) || r_addr==0 % broadcast packet
                        pkt_=obj.recvDATA(pkt_);        
                    end
            end
        end
        
        function setNAV(obj,NAV_time_) 
            if obj.NAVendTime < NAV_time_ + scheduler.getNow() % should set/update NAV
                switch obj.csState
                    case 'noCSnoNAV'
                        obj.NAVTimer.sched(NAV_time_);
                        obj.csState='noCSNAV';
                        if strcmp(obj.bkState,'RUNNING')
                            obj.pauseBK();
                        end
                    case 'noCSNAV'
                        obj.NAVTimer.resched(NAV_time_);
                    case 'CSnoNAV'   
                        obj.NAVTimer.sched(NAV_time_);
                        obj.csState='CSNAV';
                    case 'CSNAV'
                        obj.NAVTimer.resched(NAV_time_);
                    case 'WIFS'
                        obj.NAVTimer.sched(NAV_time_);
                        obj.csState='noCSNAV';
                        obj.IFSTimer.cancel();
                    otherwise
                        error('No such channel state ''%s'' in IEEE802_11MAC.',obj.csState);                    
                end
                obj.NAVendTime = NAV_time_ + scheduler.getNow();
            end
        end
        
        function channelBusy(obj) 
            switch obj.csState
                case 'WIFS'
                    obj.IFSTimer.cancel();
                    %fprintf('Node[%d] set CSnoNAV 2\n',obj.Node.id);
                    obj.csState='CSnoNAV';
                case 'noCSnoNAV'
                    switch obj.bkState
                        case 'RUNNING'
                            obj.pauseBK();
                        case 'IDLE'
                            % nothing to do
                        case 'PAUSE'
                            % nothing to do
                        otherwise
                            error('No such backoff state ''%s'' in IEEE802_11MAC.',obj.bkState);       
                    end
                    %fprintf('Node[%d] set CSnoNAV 3\n',obj.Node.id);
                    obj.csState='CSnoNAV';
                case 'noCSNAV'
                    obj.csState='CSNAV';
                case 'CSnoNAV'
                    % channel is already busy, nothing to do
                case 'CSNAV'
                    % channel is already busy, nothing to do
                otherwise
                    error('No such channel state ''%s'' in IEEE802_11MAC.',obj.csState);                    
            end
        end
        
        function channelIdle(obj) 
            %fprintf('Node[%d] channel idle cs=%s\n',obj.Node.id,obj.csState);
            switch obj.csState
                case 'noCSnoNAV'
                    % channel is already idle, nothing to do
                case 'noCSNAV'
                    % channel is already idle, nothing to do
                case 'CSnoNAV'
                    if strcmp(obj.tranState,'SENDING_RTS') || strcmp(obj.tranState,'SENDING_DATA')
                        % nothing to do, it should be busy when sending
                    elseif strcmp(obj.recvState,'WAIT_SIFS') || strcmp(obj.tranState,'WAIT_SIFS')
                        obj.csState='noCSnoNAV';                        
                    else
                        obj.IFSTimer.sched(obj.IFS);
                        %fprintf('Node[%d] set WIFS 2 at%.9f, bkState=%s\n',obj.Node.id,scheduler.getNow(),obj.bkState);
                        obj.csState='WIFS';         
                    end
                case 'CSNAV'
                    obj.csState='noCSNAV';
                case 'WIFS'
                    % channel is already idle, nothing to do
                otherwise
                    error('No such channel state ''%s'' in IEEE802_11MAC.',obj.csState);                    
            end
        end        
        
        function runBKTimer(obj) 
            %fprintf('Node[%d] runBKTimer recvState=%s tranState=%s\n',obj.Node.id,obj.recvState,obj.tranState);
            %fprintf('Node[%d] runBKTimer slots=%d time=%.9f\n',obj.Node.id,obj.bkSlots,obj.bkSlots*obj.slotTime);
            if obj.bkSlots==0
                obj.bkDone();
            else
                obj.bkState='RUNNING';
                obj.bkStartTime=scheduler.getNow();
                obj.BKTimer.sched(obj.bkSlots*obj.slotTime);
            end
        end
        
        function startBK(obj) 
            %fprintf('Node[%d] startBK backoff state=%s\n',obj.Node.id,obj.bkState);
            switch obj.bkState
                case 'IDLE' 
                    obj.bkSlots=round(rand()*(obj.CW+1));
                    obj.bkStartTime=-1;
                    %fprintf('Node[%d] startBK csState=%s \n',obj.Node.id,obj.csState);
                    if strcmp(obj.csState,'noCSnoNAV')
                        obj.runBKTimer();
                    else
                        obj.bkState='PAUSE';
                    end
                case 'RUNNING'
                    % nothing to do
                case 'PAUSE'
                    % nothing to do
                    % to continue backoff please use runBKTimer()
                otherwise
                    error('Error backoff state ''%s''.',obj.bkState);
            end
        end
        
        function pauseBK(obj) 
            obj.bkState='PAUSE';
            if obj.bkStartTime < 0
                error('Cannot pause backoff because bkStartTime is %.9f.',obj.bkStartTime);
            end
            obj.bkSlots=obj.bkSlots-floor((scheduler.getNow()-obj.bkStartTime)/obj.slotTime);
            obj.BKTimer.cancel();
            obj.bkStartTime = -1;
        end
        
        function bkDone(obj) 
            %fprintf('Node[%d] bkDone\n',obj.Node.id);
            obj.bkState='IDLE';
            obj.bkSlots=-1;
            obj.bkStartTime=-1;
            switch obj.tranState     % transmit state 'IDLE' 'RTS_PENDING' 'DATA_PENDING' 'SENDING_RTS' 'SENDING_DATA' 'WAIT_CTS' 'WAIT_ACK' 'WAIT_SIFS'
                case 'RTS_PENDING'                    
                    if strcmp(obj.csState,'noCSnoNAV') && strcmp(obj.recvState,'IDLE') 
                        obj.transmit(obj.pktRTS);
                        %fprintf('Node[%d] send RTS 1 at %.9f\n',obj.Node.id,obj.Node.Scheduler.getNow());
                        obj.tranState='SENDING_RTS';
                    end
                case 'DATA_PENDING'
                    obj.transmit(obj.pktDATA);
                    obj.tranState='SENDING_DATA';
                case 'IDLE'
                    % nothing to do
                case 'WAIT_CTS'
                    % nothing to do
                case 'WAIT_ACK'
                    % nothing to do
                otherwise
                    error('Error transmit state ''%s'' in MAC.',obj.tranState);
            end
        end
        
        function timerExpire(obj,timerId) 
            switch timerId
                case 'BKTimer' 
                    if strcmp(obj.bkState,'RUNNING')
                        obj.bkDone();
                    else
                        error('Backoff state error, now should not be ''%s''.',obj.bkState);
                    end
                case 'NAVTimer' 
                    obj.NAVendTime=-1;
                    switch obj.csState
                        case 'noCSNAV'
                            %fprintf('Node[%d] set WIFS 3 at%.9f, tranState=%s recvState=%s csState=%s\n',obj.Node.id,scheduler.getNow(),obj.tranState,obj.recvState,obj.csState);
                            if strcmp(obj.recvState,'WAIT_SIFS') || strcmp(obj.tranState,'WAIT_SIFS')
                                obj.csState='noCSnoNAV';  
                            else
                                obj.IFSTimer.sched(obj.IFS);
                            end
                            %fprintf('Node[%d] set WIFS 3 at%.9f, bkState=%s\n',obj.Node.id,scheduler.getNow(),obj.bkState);
                            obj.csState='WIFS';
                        case 'CSNAV'
                            %fprintf('Node[%d] set CSnoNAV 1\n',obj.Node.id);
                            obj.csState='CSnoNAV';
                        otherwise
                            error('Error cahnnel state ''%s'' when NAV timer expired.',obj.csState);
                    end
                case 'TranTimer' 
                    if strcmp(obj.tranState,'WAIT_CTS')
                        obj.shortRetryCounter=obj.shortRetryCounter+1;
                        obj.CW=obj.CW*2+1;
                        if obj.CW > obj.CWmax
                            obj.CW = obj.CWmax;
                        end
                        
                        if obj.shortRetryCounter > obj.shortRetryLimit
                            obj.shortRetryCounter=0;
                            obj.longRetryCounter=0;
                            obj.pktRTS=[];
                            obj.pktDATA=[];
                            obj.CW = obj.CWmin;                            
                            obj.tranState='IDLE';
                            obj.startBK();
                            obj.DLL.checkQueue();
                        else
                            obj.tranState='RTS_PENDING';
                            %fprintf('Node[%d] startBK 1\n',obj.Node.id);
                            obj.startBK();
                        end
                    elseif strcmp(obj.tranState,'WAIT_ACK')
                        if obj.pktDATA.size > obj.RTSthreshold
                            obj.longRetryCounter=obj.longRetryCounter+1;
                        else
                            obj.shortRetryCounter=obj.shortRetryCounter+1;
                        end
                        
                        obj.CW=obj.CW*2+1;
                        if obj.CW > obj.CWmax
                            obj.CW = obj.CWmax;
                        end
                        
                        if obj.longRetryCounter > obj.longRetryLimit || obj.shortRetryCounter > obj.shortRetryLimit
                            obj.shortRetryCounter=0;
                            obj.longRetryCounter=0;
                            obj.pktDATA=[];
                            obj.CW = obj.CWmin;                            
                            obj.tranState='IDLE';
                            obj.startBK();
                            obj.DLL.checkQueue();
                        else                      
                            if isempty(obj.pktRTS)
                                obj.tranState='DATA_PENDING';
                            else
                                obj.tranState='RTS_PENDING';
                            end
                            obj.startBK();
                        end
                    else
                        error('Error transmit state ''%s'' when transmit timer expired.',obj.tranState);
                    end
                case 'IFSTimer' 
                    if strcmp(obj.recvState,'WAIT_SIFS')   % judge receving state first
                        obj.transmit(obj.pktCtrl);
                        obj.recvState='RESPONSING';
                    elseif strcmp(obj.csState,'WIFS')                        
                        obj.csState='noCSnoNAV';
                        %fprintf('Node[%d] IFS timer expired, channel state change to noCSnoNAV, backoff state=%s\n',obj.Node.id,obj.bkState);
                        switch obj.bkState
                            case 'PAUSE'
                                obj.runBKTimer();
                            case 'IDLE'
                                % nothing to do
                            otherwise
                                error('Node[%d] Error backoff state ''%s'' when IFS timer expired.',obj.Node.id,obj.bkState);
                        end
                    elseif strcmp(obj.tranState,'WAIT_SIFS')
                        obj.transmit(obj.pktDATA);
                        obj.tranState='SENDING_DATA';
                    else
                        error('State error when IFS timer expired.');
                    end
                otherwise
                    error('No such timer ''%s'' in IEEE802_11MAC.',timerId);
            end
        end
        
        function tranEnd(obj) 
            if strcmp(obj.recvState,'RESPONSING')
                obj.pktCtrl=[];
                obj.recvState='IDLE';
            elseif strcmp(obj.tranState,'SENDING_RTS')  
                obj.TranTimer.sched(obj.SIFS + obj.CTStime + obj.maxPropagationDelay);
                obj.tranState='WAIT_CTS';
            elseif strcmp(obj.tranState,'SENDING_DATA')
                r_addr=obj.pktDATA.nextHop;
                if isempty(r_addr) || r_addr==0 % broadcast packet
                    obj.pktDATA=[];                
                    obj.tranState='IDLE';
                    obj.startBK();
                    obj.DLL.checkQueue();
                else
                    obj.TranTimer.sched(obj.SIFS + obj.ACKtime + obj.maxPropagationDelay);                
                    obj.tranState='WAIT_ACK';
                end                
            else
                error('State error when transmition end.');
            end
        end
        
        function transmit(obj,pkt_) 
            pkt_.layer='MAC';
            pkt_.lastHop=obj.Node.id;
            pkt_.header.head_duration=obj.headerDuration;            
            obj.PHY.recv(pkt_);
        end
        
        function genFrameRTS(obj) % calculate txtime of data here 
            obj.pktRTS=packet();
            obj.pktRTS.header.frameType='RTS';
            obj.pktRTS.type='RTS';
            obj.pktRTS.sourceAddr=obj.Node.id;
            obj.pktRTS.nextHop=obj.pktDATA.nextHop;
            obj.pktRTS.destAddr=obj.pktDATA.destAddr;
            obj.pktRTS.size=obj.RTSlen;
            obj.pktRTS.header.txTime=obj.RTStime - obj.headerDuration; % transmition time without header (s)
                                             
            % change modulate mode to change rate for Link Adaptation
            obj.pktDATA.moduMode='BPSK';  % empty value is the same as basic mode 'BPSK'
            
            if isfield(constants.IEEE802_11ModuTable,obj.pktDATA.moduMode)
                index=eval(['constants.IEEE802_11ModuTable.' obj.pktDATA.moduMode]);
            else
                error('No parameter for such modulate mode ''%s''.',obj.pktDATA.moduMode);
            end
            
            symbols = ceil(obj.pktDATA.size *8 / constants.IEEE802_11ModuTable(index).NDBPS);
            obj.pktDATA.header.txTime=symbols * obj.symbolDuration; % transmition time without header (s)

            obj.pktRTS.header.NAV = obj.SIFS*3 + obj.CTStime + obj.ACKtime +...
                                    obj.headerDuration + obj.pktDATA.header.txTime;            
        end
        
        function genFrameCTS(obj,pkt_) 
            obj.pktCtrl=packet();
            obj.pktCtrl.header.frameType='CTS';
            obj.pktCtrl.type='CTS';
            obj.pktCtrl.sourceAddr=obj.Node.id;
            obj.pktCtrl.nextHop=pkt_.sourceAddr;
            obj.pktCtrl.destAddr=pkt_.sourceAddr;
            obj.pktCtrl.size=obj.CTSlen;
            obj.pktCtrl.header.txTime=obj.CTStime - obj.headerDuration; % transmition time without header (s)
            obj.pktCtrl.header.NAV=pkt_.header.NAV - obj.SIFS - obj.CTStime;
        end
        
        function genFrameDATA(obj,pkt_) 
            if isfield(pkt_.header,'frameType') && strcmp(pkt_.header.frameType,'DATA')
                error('Cannot generate DATA frame, because the packet has already been generated as DATA frame.');
            end
            obj.pktDATA=pkt_;
            obj.pktDATA.header.frameType='DATA';
            % do not change packet type here
            if strcmp(obj.type,'AP')
                obj.pktDATA.nextHop=obj.recvNode(obj.staIndex);
                obj.pktDATA.destAddr=obj.recvNode(obj.staIndex);   
                obj.staIndex=obj.staIndex+1;
                if obj.staIndex > numel(obj.recvNode)
                    obj.staIndex = 1;
                end
            else
                obj.pktDATA.nextHop=obj.recvNode(1);
                obj.pktDATA.destAddr=obj.recvNode(1);    
            end
            
            if isempty(obj.pktDATA.nextHop) || obj.pktDATA.nextHop == 0 % broadcast, no ACK 
                obj.pktDATA.header.NAV = 0;    
            else 
                obj.pktDATA.header.NAV = obj.SIFS + obj.ACKtime;
            end            
            
            obj.pktDATA.size=obj.MACheaderLen + obj.pktDATA.size + obj.FCSlen;  
            % txtime of data is calculated at genFrameRTS
        end        
        
        function genFrameACK(obj,pkt_) 
            obj.pktCtrl=packet();
            obj.pktCtrl.header.frameType='ACK';
            obj.pktCtrl.type='ACK';
            obj.pktCtrl.sourceAddr=obj.Node.id;
            obj.pktCtrl.nextHop=pkt_.sourceAddr;
            obj.pktCtrl.destAddr=pkt_.sourceAddr;
            obj.pktCtrl.size=obj.ACKlen;
            obj.pktCtrl.header.txTime=obj.ACKtime - obj.headerDuration; % transmition time without header (s)
            obj.pktCtrl.header.NAV=0;
        end
        
        function pkt_=recvDATA(obj,pkt_) 
            % drop MAC header and FCS
            pkt_.size=pkt_.size - obj.MACheaderLen - obj.FCSlen;
        end
    end
    
end

