classdef baseNode < handle
    %BASENODE ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        id
        Scheduler
        APP % application for generating/destroying data
        DLL % data link layer for storing data in queues
        MAC % MAC layer for implementing MAC protocol
        PHY % PHY layer for connecting channel
        %!!!! node positon (X,Y,Z) is defined in PHY layer!!!!
        
        traceMAC % trace packet dealed in MAC or not
        tracePHY % trace packet dealed in PHY or not
    end
        
    properties (Constant,Hidden)
        nodeNum=counter();
    end
    
    methods
        function obj = baseNode()
            obj.nodeNum.incr();
            obj.id=obj.nodeNum.value;
            obj.Scheduler=scheduler.getThis();
        end
        
        function config(obj,parameter)            
            obj.traceMAC=parameter.traceMAC; 
            obj.tracePHY=parameter.tracePHY;
        end
        
        function trace(obj,pkt_)
            if ~isempty(pkt_)
                if (~obj.traceMAC && strcmp(pkt_.layer,'MAC')) || ...
                        (~obj.tracePHY && strcmp(pkt_.layer,'PHY')) 
                    return;
                end
                now=obj.Scheduler.Clock.now;
                info=sprintf('%.9f [%d]',now,obj.id);
                if pkt_.isSendUp
                    action='r';
                else
                    action='s';
                end
                info=sprintf('%s %s %s',info,action,pkt_.layer); 
                if isempty(pkt_.nextHop) % broadcast packet
                    pkt_.nextHop=0;
                end
                info=sprintf('%s %d %.9f %d %s',info,pkt_.id,pkt_.genTime,pkt_.size,pkt_.type);
                info=sprintf('%s [%d->%d]',info,pkt_.lastHop,pkt_.nextHop);                
                
                fprintf(obj.Scheduler.traceFile,'%s\n',info);
            end
        end
        
        function createAPP(obj,app_type,parameter)
            if nargin == 2
                parameter=defaultConfig(app_type);
            end
            parameter.Node=obj;
            obj.APP=eval(strcat('node.app.',app_type,'(parameter)'));
        end
        
        function createDLL(obj,dll_type,parameter)
            if nargin == 2
                parameter=defaultConfig(dll_type);
            end
            parameter.Node=obj;
            obj.DLL=eval(strcat('node.dll.',dll_type,'(parameter)'));
        end
        
        function createMAC(obj,mac_type,parameter)
            if nargin == 2
                parameter=defaultConfig(mac_type);
            end
            parameter.Node=obj;
            obj.MAC=eval(strcat('node.mac.',mac_type,'(parameter)'));
        end
        
        function createPHY(obj,phy_type,parameter)
            if nargin == 2
                parameter=defaultConfig(phy_type);
            end
            parameter.Node=obj;
            
            if ~isfield(parameter,'Channel')
                parameter.Channel=obj.Scheduler.Channel;
            end
            obj.PHY=eval(strcat('node.phy.',phy_type,'(parameter)'));
        end
        
        function connectAllLayer(obj)
            obj.APP.DLL=obj.DLL;
            obj.DLL.APP=obj.APP;
            obj.DLL.MAC=obj.MAC;
            obj.MAC.DLL=obj.DLL;
            obj.MAC.PHY=obj.PHY;
            obj.PHY.MAC=obj.MAC;
        end
        
        function setPosition(obj,x_,y_,z_)
            if isempty(obj.PHY)
                error('Set node position error. Node position is defined in PHY. Please create PHY first.');
            end
            obj.PHY.X=x_;
            obj.PHY.Y=y_;
            if nargin > 3
                obj.PHY.Z=z_;
            end
        end
        
        function [x_,y_,z_] = getPosition(obj)
            if isempty(obj.PHY)
                error('Get node position error. Node position is defined in PHY. Please create PHY first.');
            end
            x_=obj.PHY.X;
            y_=obj.PHY.Y;
            z_=obj.PHY.Z;
        end
    end
    
end

