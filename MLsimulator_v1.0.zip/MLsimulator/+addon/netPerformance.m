function [throughput_, delay_]=netPerformance(trace_file)    
    % throughput
    trace_file=fopen(trace_file);
    time_start=cell2mat(textscan(trace_file,'%f',1,'headerlines',1));    
    recv_size=0;
    
    % delay
    pkt_num=0;
    delay_=0;
    while 1
        % read trace        
        text=textscan(trace_file,'%f %s %s %s %d %f %d %s %s',1,'headerlines',1);
        time = text{1};
        node_id = text{2};
        action = text{3}; 
        layer = text{4};
        %packet_id = text{5}; 
        packet_gen_time = text{6}; 
        packet_size = text{7};
        packet_type = text{8};
        %direction = text{9};
        if isempty(time)
            break;
        else
            time_end=time;
        end

        % calculate
        if strcmp(layer,'MAC') && strcmp(packet_type,'cbr') && strcmp(action,'r')
            % throughput
            recv_size=recv_size+packet_size;
            
            % delay
            pkt_num=pkt_num+1;
            delay_=delay_ + time - packet_gen_time;
        end
    end
    
    fclose(trace_file);
    throughput_=double(recv_size)/(time_end-time_start);
    delay_=delay_/pkt_num;
end

