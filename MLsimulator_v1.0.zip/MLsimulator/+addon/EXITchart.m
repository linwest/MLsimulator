function EXITchart()
    clc
    IA1=[];
    IE1=[];
    IA2=[];
    IE2=[];
    IA_num=21;
    seq_num=10000;
    seq=round(rand(1,seq_num));

    SNR_dB=-5.0;
    SNR=10^(SNR_dB/10);
    Lc_outer_code=1;
    Lc_inner_code=4*SNR;
    
    modulation='BPSK';

    codePara1.type='CC'; % use which code
    codePara1.code_book=[0 1;  
                         1 1]; 
    codePara1.feedback=[];  
    codePara1.Lc=Lc_outer_code;
    codePara1.code_position='outerCode';    
    %------------------------------
    codePara2.type='CC'; % use which code
    codePara2.code_book=[0 1;  
                         1 1]; 
    codePara2.feedback=[1 1;
                        0 0];
    codePara2.Lc=Lc_inner_code;
    codePara2.code_position='innerCode';
    %-----------------------------------------outer code-------------------------------------------------  
    seq_code1=node.phy.encoder.code(seq,codePara1); % SRCC
    seq2=seq_code1;
    %-----------------------------------------inner code------------------------------------------------- 
    seq_code2=node.phy.encoder.code(seq2,codePara2);
    seq_code2=node.phy.modulator.modulate(seq_code2,modulation);
    seq_code2=seq_code2+sqrt(0.5/SNR)*(randn(size(seq_code2))+1i*randn(size(seq_code2))); %AWGN
    seq_code2=node.phy.modulator.demodulate(seq_code2,modulation,SNR); %BPSK demodulator

    % x axis
    x=0.9999/(IA_num-1)*(0:(IA_num-1));
    sigma=power(-1/0.3073*log2(1-power(x,1/1.1064)),0.5/0.8935);
    
    for i=1:IA_num
        %-----------------------------------------outer code-------------------------------------------------  
        codePara1.La=zeros(size(seq));        
        seq_tmp1=(seq_code1*2-1)*0.5*sigma(i)^2+randn(size(seq_code1))*sigma(i);  % La=u_A*seq+n_A; u_A=��^2/2
        [~,output]=node.phy.decoder.code(seq_tmp1,codePara1);
        Le=output.LLR_code-seq_tmp1;
        IE1(i)=mutual_info(Le,seq);        
        %-----------------------------------------inner code------------------------------------------------- 
        codePara2.La=(seq2*2-1)*0.5*sigma(i)^2+randn(size(seq2))*sigma(i);  % La=u_A*seq+n_A; u_A=��^2/2
        [~,output]=node.phy.decoder.code(seq_code2,codePara2);
        Le=output.LLR-codePara2.La;
        IE2(i)=mutual_info(Le,seq2);
    end
    x_traj=0;
    y_traj=IE2(1);
    i=1;
    while true
        %-----------------------------------------outer code-------------------------------------------------  
        i=i+1;      
        sigma_t=power(-1/0.3073*log2(1-power(y_traj(i-1),1/1.1064)),0.5/0.8935);
        codePara1.La=zeros(size(seq));        
        seq_tmp1=(seq_code1*2-1)*0.5*sigma_t^2+randn(size(seq_code1))*sigma_t;  % La=u_A*seq+n_A; u_A=��^2/2
        [~,output]=node.phy.decoder.code(seq_tmp1,codePara1);
        Le=output.LLR_code-seq_tmp1;
        x_traj(i)=mutual_info(Le,seq);    
        y_traj(i)=y_traj(i-1);
        %-----------------------------------------inner code------------------------------------------------- 
        i=i+1;
        sigma_t=power(-1/0.3073*log2(1-power(x_traj(i-1),1/1.1064)),0.5/0.8935);
        codePara2.La=(seq2*2-1)*0.5*sigma_t^2+randn(size(seq2))*sigma_t;  % La=u_A*seq+n_A; u_A=��^2/2
        [~,output]=node.phy.decoder.code(seq_code2,codePara2);
        Le=output.LLR-codePara2.La;
        
        x_traj(i)=x_traj(i-1);
        y_traj(i)=mutual_info(Le,seq2);
        if x_traj(i)-x_traj(i-1)<0.001 && y_traj(i)-y_traj(i-1)<0.001
            break;
        end
    end
    figure('NumberTitle', 'off','name','EXIT Chart');
    line_IA=plot(x,IE2,'b-o','MarkerFaceColor','b');
    hold on;
    line_IE=plot(IE1,x,'-o','Color',[0 0.5 0]);
    line_trajectory=plot(x_traj,y_traj,'-.','Color',[0.5 0.5 0]);
    lines=[line_IE line_IA line_trajectory];
    title('EXIT Chart');
    xlabel('I_A^{inner} = I_E^{outer}'); 
    ylabel('I_E^{inner} = I_A^{outer}'); 
    legend(sprintf('Inner code, %s, SNR = %g dB',modulation,SNR_dB),'Outer code','Trajectory','location','northwest');
    set(lines,'Markersize',5);
    set(lines,'LineWidth',1.2);
    hold off;
end

function I=mutual_info(La,seq)
    P0 = exp(La)./(1+exp(La));
    P1 = 1-P0;
    entropies = -P0.*log2(P0)-P1.*log2(P1);
    I = 1-sum(entropies(~isnan(entropies)))/length(entropies);
end