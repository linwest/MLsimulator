classdef wireless < handle
    %WIRELESS ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties (SetAccess = private)
        Scheduler
        phyList
        phyNum      % number of phy in list
        noisePower  % average noise power (W)     
        centerFreq  % center frequency (Hz)
    end
    
    methods
        function obj = wireless()
            obj.Scheduler=scheduler.getThis();
            obj.phyList=struct('PHY',{});
            obj.phyNum=0;
        end   
        
        function config(obj,parameter)
            obj.noisePower=parameter.noisePower;
            obj.centerFreq=parameter.centerFreq;
        end
                
        function addPHY(obj,phy_)
            obj.phyList(end+1).PHY=phy_;
            obj.phyNum=obj.phyNum+1;
        end
        
        function recv(obj,pkt_,send_node_)   
            % receive packet from PHY
            send_node_.trace(pkt_);          
            pkt_.isSendUp=true;   
            
            now_=obj.Scheduler.Clock.now;
            %=======broadcast============
            for i=1:obj.phyNum
                phy_=obj.phyList(i).PHY;
                if send_node_.id == phy_.Node.id
                    continue;
                end
                [x_,y_]=send_node_.getPosition();  % Z is not often used, omit it for efficiency
                d_=sqrt((phy_.X-x_)^2+(phy_.Y-y_)^2);      
                
                Lfs=20*log10(d_*obj.centerFreq)-147.56;
                if (pkt_.power/10^(Lfs/10)) < phy_.PowerMonitor.thresh
                    % packet can not be sensed
                    continue;
                end
                
                pkt_tmp=pkt_;
                pkt_tmp.recvTime=now_+d_/constants.c;
                                
                % calculate fading before sending
                if (isempty(pkt_tmp.nextHop) || pkt_tmp.nextHop==0 || pkt_tmp.nextHop==phy_.Node.id) ...   % broadcast or send to this node
                    && (~isempty(pkt_tmp.data))      % and contain bit sequence
                    pkt_tmp=obj.bitFading(pkt_tmp,send_node_.PHY,phy_);
                else
                    pkt_tmp.originalData=[];
                    pkt_tmp.data=[];
                    pkt_tmp=obj.pktFading(pkt_tmp,send_node_.PHY,phy_);
                end

                % send packet to specifed PHY
                phy_.recv(pkt_tmp);
                
            end
            %=======broadcast end========
        end
        
        function pkt_ = pktFading(obj, pkt_, s_phy_, r_phy_) % apply fading to packet            
            d_=sqrt((s_phy_.X-r_phy_.X)^2+(s_phy_.Y-r_phy_.Y)^2);    % Z is not often used, omit it for efficiency 
            Lfs=20*log10(d_*obj.centerFreq)-147.56;
            if Lfs>0
                pkt_.power=pkt_.power/10^(Lfs/10);
            end
        end
        
        function pkt_ = bitFading(obj, pkt_, s_phy_, r_phy_) % apply fading to each bit
            pkt_=obj.pktFading(pkt_, s_phy_, r_phy_);
            
            pkt_.data= pkt_.data + sqrt(0.5 / pkt_.power * obj.noisePower) *...
                       (randn(size(pkt_.data))+1i*randn(size(pkt_.data)));
        end
    end
    
end

