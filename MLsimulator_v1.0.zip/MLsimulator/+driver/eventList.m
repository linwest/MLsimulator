classdef eventList < handle
    %EVENTLIST ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties
        endTime
        event
        timerList
        expireTime
        priority        
    end
    
    methods
        function obj=eventList()
            obj.init();
        end
        
        function obj=init(obj)
            obj.endTime=1;
            obj.event=[];
            obj.timerList=[];
            obj.expireTime=[];
            obj.priority=[];
        end
        
        function addTimer(obj,timer_)
            if isempty(obj.timerList)
                obj.timerList=timer_;
            else
                obj.timerList(end+1)=timer_;
            end
            %fprintf('timer num=%d, id=%d\n',numel(obj.timerList),timer_.id);
        end
        
        function addEvent(obj,call_back_,expire_time_,priority_)
            if expire_time_ < obj.endTime
                index=find(obj.expireTime==expire_time_);

                if ~isempty(index)
                    offset=find(obj.priority(index)>priority_,1);
                    if isempty(offset)
                        offset=numel(index)+1;
                    end
                    i=index(1)+offset-2;
                    obj.event=[obj.event(1:i) call_back_ obj.event(i+1:end)];
                    obj.expireTime=[obj.expireTime(1:i) expire_time_ obj.expireTime(i+1:end)];
                    obj.priority=[obj.priority(1:i) priority_ obj.priority(i+1:end)];                  
                else                
                    index=find(obj.expireTime<expire_time_,1,'last');
                    if isempty(index)
                        obj.event=[call_back_ obj.event];
                        obj.expireTime=[expire_time_ obj.expireTime];
                        obj.priority=[priority_ obj.priority];  
                    else
                        i=index(end);
                        obj.event=[obj.event(1:i) call_back_ obj.event(i+1:end)];
                        obj.expireTime=[obj.expireTime(1:i) expire_time_ obj.expireTime(i+1:end)];
                        obj.priority=[obj.priority(1:i) priority_ obj.priority(i+1:end)];  
                    end
                end
            
%=============sort results test===============================
%                 s_e='e:';
%                 s_p='p:';
%                 s_c='c:';
%                 for i=1:numel(obj.expireTime)
%                     s_e=sprintf('%s\t%g',s_e,obj.expireTime(i));
%                     s_p=sprintf('%s\t%g',s_p,obj.priority(i));
%                     s_c=sprintf('%s\t%g',s_c,obj.event(i).callBack.state);
%                 end
%                 disp(s_e);
%                 disp(s_p);
%                 disp(s_c);
%=============sort results test END===============================
            end
        end
        
        function delEvent(obj,call_back_)
            i=find(obj.event==call_back_,1);  % There can only be most one event for the same callback;
            if ~isempty(i);
                obj.event=[obj.event(1:i-1) obj.event(i+1:end)];
                obj.expireTime=[obj.expireTime(1:i-1) obj.expireTime(i+1:end)];
                obj.priority=[obj.priority(1:i-1) obj.priority(i+1:end)];  
            end
        end
        
        % execute next event
        function exeEvent(obj)
            global Scheduler;
            while numel(obj.expireTime) > 0     
                Scheduler.Clock.setTime(obj.expireTime(1));
                obj.timerList(obj.event(1)).expire();
                
                % delete the executed event
                obj.event=obj.event(2:end);
                obj.expireTime=obj.expireTime(2:end);
                obj.priority=obj.priority(2:end);
            end
        end
    end
    
end

