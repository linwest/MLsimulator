classdef callBackTimer < driver.timer
    %CALLBACKTIMER ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
	properties
        parent
        subId  % separete different callBackTimers in parent
    end
    
    methods
        function obj = callBackTimer(parent_,subId_)              
            if nargin > 1
                obj.initialize();
                obj.parent=parent_;            
                if nargin>1
                    obj.subId=subId_;
                end
            else
                error('test');
            end
        end
        
        function expire(obj)
            obj.state='HANDLING';
            if isempty(obj.subId)
                obj.parent.timerExpire();           % callback for callBackTimer
            else
                obj.parent.timerExpire(obj.subId);  % callback for callBackTimer
            end
            obj.state='IDLE';               
        end        
    end
    
end

