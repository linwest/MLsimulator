classdef clock < handle
    %CLOCK ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties (SetAccess = private)
        now
        interval
    end
    
    methods
        function obj=clock()
            obj.init();
        end        
        
        function obj=init(obj)
            obj.interval=constants.MIN_TIME_INTERVAL;
            obj.now=0.0*obj.interval;
        end
        
        function setInterval(obj,interval_)
            obj.interval=interval_;
            obj.now=0.0*obj.interval;
        end
        
        function setTime(obj,time_)
            obj.now=time_;
        end
    end
    
end

