classdef timer < handle
    %TIMER ���̃N���X�̊T�v�������ɋL�q
    %   �ڍא����������ɋL�q
    
    properties (SetAccess = protected)
        state
        id
    end    
    
    properties (SetAccess = private, Hidden)
        Scheduler
    end    
    
    properties (Constant,Hidden)
        timerNum=counter();
    end
    
    methods
        function obj=timer()
            % matlab will call constructor for extra time in some case
            % such as meeting the requirement of data structure when matrix adds a row
            % in these case, constructor will be called without input
            % so has to explicitly call another function to initialize it
            obj.state='NOT_INITIALIZED';
        end
        
        function initialize(obj)
            obj.timerNum.incr();
            obj.id=obj.timerNum.value;
            obj.state='IDLE';
            obj.Scheduler=scheduler.getThis();   
            obj.Scheduler.EventList.addTimer(obj);
        end
        
        function sched(obj,delay_,priority_)
            if ~isequal(obj.state,'IDLE') && ~isequal(obj.state,'HANDLING')
                error('Timer cannot be scheduled because it is ''%s'' now. Please check it.',obj.state);
            end            
            if isempty(delay_) || delay_<0
                error('Timer cannot schedule an event %.9fs before now. The delay must be no less than 0 and not empty.',delay_);
            end
            if nargin==2
                priority_=5;
            end            
            obj.Scheduler.EventList.addEvent(obj.id,delay_+obj.Scheduler.Clock.now,priority_);
            obj.state='RUNNING';
        end
        
        function resched(obj,delay_,priority_)
            if nargin==2
                priority_=5;
            end
             obj.cancel();
             obj.sched(delay_,priority_);
        end
        
        function cancel(obj)
            obj.Scheduler.EventList.delEvent(obj.id);
            obj.state='IDLE';            
        end
                
        function expire(obj)
            obj.state='HANDLING';
            obj.execute();
            obj.state='IDLE';               
        end        
        
        function execute(obj)
            % Please overload this function for a specified Timer
        end
    end
end

